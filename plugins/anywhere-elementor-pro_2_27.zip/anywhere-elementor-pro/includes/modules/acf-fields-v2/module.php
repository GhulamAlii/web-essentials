<?php

namespace Aepro\Modules\AcfFieldsV2;

use Aepro\Base\ModuleBase;

class Module extends ModuleBase {

	public function get_widgets() {
		return [
			'ae-acf-fields-v2',
		];
	}

}
