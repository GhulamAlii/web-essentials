<?php
namespace Aepro\Modules\DynamicMap\Classes;

use Aepro\Classes\QueryMaster;

class Query extends QueryMaster {

	public $filter_slug = 'dynamic-map';

}
