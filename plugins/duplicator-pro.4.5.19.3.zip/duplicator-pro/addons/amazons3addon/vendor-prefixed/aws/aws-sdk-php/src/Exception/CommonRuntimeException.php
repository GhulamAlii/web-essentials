<?php

namespace VendorDuplicator\Aws\Exception;

class CommonRuntimeException extends \RuntimeException
{
}
