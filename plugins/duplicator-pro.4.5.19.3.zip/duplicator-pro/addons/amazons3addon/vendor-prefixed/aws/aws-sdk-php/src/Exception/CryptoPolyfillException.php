<?php

namespace VendorDuplicator\Aws\Exception;

/**
 * Class CryptoPolyfillException
 * @package VendorDuplicator\Aws\Exception
 */
class CryptoPolyfillException extends \RuntimeException
{
}
