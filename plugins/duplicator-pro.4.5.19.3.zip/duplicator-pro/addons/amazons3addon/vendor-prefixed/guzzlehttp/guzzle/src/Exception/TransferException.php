<?php

namespace VendorDuplicator\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
