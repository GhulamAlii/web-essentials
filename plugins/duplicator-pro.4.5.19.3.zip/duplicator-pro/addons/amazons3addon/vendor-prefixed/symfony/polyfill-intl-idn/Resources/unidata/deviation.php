<?php

namespace VendorDuplicator;

return array(223 => 'ss', 962 => 'σ', 8204 => '', 8205 => '');
