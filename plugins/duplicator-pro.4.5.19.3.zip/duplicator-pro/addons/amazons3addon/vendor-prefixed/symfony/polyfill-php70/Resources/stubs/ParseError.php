<?php

namespace VendorDuplicator;

class ParseError extends \Error
{
}
\class_alias('VendorDuplicator\\ParseError', 'ParseError', \false);
