<?php

namespace VendorDuplicator\Dropbox\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
