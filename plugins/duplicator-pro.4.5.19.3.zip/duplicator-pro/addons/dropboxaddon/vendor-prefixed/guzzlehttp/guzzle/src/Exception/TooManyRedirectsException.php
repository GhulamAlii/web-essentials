<?php

namespace VendorDuplicator\Dropbox\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
