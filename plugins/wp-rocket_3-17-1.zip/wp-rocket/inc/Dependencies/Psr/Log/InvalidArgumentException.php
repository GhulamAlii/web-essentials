<?php

namespace WP_Rocket\Dependencies\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
