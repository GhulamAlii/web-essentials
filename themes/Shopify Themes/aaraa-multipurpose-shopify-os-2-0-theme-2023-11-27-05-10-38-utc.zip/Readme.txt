Within the main folder [themeforest-aaraa-multipurpose-shopify-theme.zip] there will be following folder and files.

Documentation
Readme.txt
Log.txt
aaraa-demo1.zip
aaraa-demo2.zip
aaraa-demo3.zip
aaraa-demo4.zip
aaraa-demo5.zip
aaraa-demo6.zip
aaraa-demo7.zip
aaraa-demo8.zip
aaraa-demo9.zip
aaraa-demo10.zip
aaraa-demo11.zip
aaraa-demo12.zip
aaraa-demo13.zip
aaraa-demo14.zip
aaraa-demo15.zip
aaraa-demo16.zip
aaraa-demo17.zip
aaraa-demo18.zip
aaraa-demo19.zip
aaraa-demo20.zip

-------------------------------------------------------------------
https://themessupport.com/wedesigntech/shopify/aaraa/


Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.











