Within the main folder [themeforest-trendz-fashion-shopify-theme.zip] there will be following folder and files.

Documentation
Readme.txt
Log.txt
trendz-demo1.zip
trendz-demo2.zip
trendz-demo3.zip
trendz-demo4.zip
trendz-demo5.zip
trendz-demo6.zip
trendz-demo7.zip
trendz-demo8.zip
trendz-demo9.zip
trendz-demo10.zip

-------------------------------------------------------------------
https://themessupport.com/wedesigntech/shopify/trendz/


Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.











